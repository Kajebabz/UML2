﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PizzaStore2
{
    public class Pizza
    {
        public static int nextId = 1;
        public Pizza()
        {
            Id = nextId++;
        }
        public Pizza(string name, string toppings, int price)
        {
            Id = nextId++;
            Name = name;
            Toppings = toppings;
            Price = price;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Toppings { get; set; }
        public int Price { get; set; }


        public override string ToString()
        {
            return "Pizza nr. " + Id + " " + Name + ", Indeholder: " + Toppings + ", og koster: " + Price + "kr";
        }
    }
}
