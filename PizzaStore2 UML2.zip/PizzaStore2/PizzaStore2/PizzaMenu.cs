﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore2
{
    public class PizzaMenu
    {
        public static Dictionary<int, Pizza> PizzaDictionary = new Dictionary<int, Pizza>();

        public static void AddPizza(Pizza pizza)
        {
            Console.WriteLine("Pizza Added");
            PizzaDictionary.Add(pizza.Id, pizza);
        }

        public static Pizza RemovePizza(int id)
        {
            if (PizzaDictionary.ContainsKey(id))
            {
                Pizza RemovedPizza = PizzaDictionary[id];
                PizzaDictionary.Remove(id);
                Console.WriteLine($"Removed Pizza {id}");
                return RemovedPizza;
            }
            else
            {
                Console.WriteLine("No pizza with that ID");
                return null;
            }
        }

        public static Pizza ReadPizzaById(int id)
        {
            if (PizzaDictionary.ContainsKey(id))
            {
                Console.WriteLine("Pizza found with that ID");
                return PizzaDictionary[id];
            }
            else
            {
                Console.WriteLine("No Pizza with that ID");
                return null;
            }
        }

        public static Pizza SearchPizzaById(int id)
        {
            if (PizzaDictionary.ContainsKey(id))
            {
                Console.WriteLine("Pizza with given ID found!");
                Console.WriteLine(PizzaDictionary[id]);
                return PizzaDictionary[id];
            }
            Console.WriteLine($"Pizza with given Id: {id}, not found!");
            return null;
        }

        public static Dictionary<int,Pizza> SearchPizzaByToppings(string topping)
        {
            Dictionary<int, Pizza> TempDict = new Dictionary<int, Pizza>();
            foreach (var pizza in PizzaDictionary)
            {
                if (pizza.Value.Toppings.Contains(topping))
                {
                    TempDict.Add(pizza.Key, pizza.Value);
                    Console.WriteLine("Search result");
                    Console.WriteLine(pizza);
                }

            }
            if(TempDict.Count == 0)
                Console.WriteLine("Nothing found in the given search");

            return TempDict;
        }

        public static void PrintPizza()
        {
            Console.WriteLine("Menukort:");
            foreach (var pizza in PizzaDictionary)
            {
                Console.WriteLine(pizza.Value);
            }
        }

        public static Pizza UpdatePizza(int id, string field, string newValue)
        {
            foreach (var p in PizzaDictionary)
            {
                if (p.Key == id)
                {
                    if (field.ToLower() == "name")
                    {
                        p.Value.Name = newValue;
                        Console.WriteLine("Pizza has been updated!");
                        Console.WriteLine(p.Value);
                        return p.Value;
                    }
                    if (field.ToLower() == "toppings")
                    {
                        p.Value.Toppings = newValue;
                        Console.WriteLine("Pizza has been updated!");
                        Console.WriteLine(p.Value);
                        return p.Value;
                    }
                    if (field.ToLower() == "price")
                    {
                        p.Value.Price = int.Parse(newValue);
                        Console.WriteLine("Pizza has been updated!");
                        Console.WriteLine(p.Value);
                        return p.Value;
                    }
                }
            }
            Console.WriteLine($"No Pizza found with that id: {id}");
            return null;
        }

    }
}
