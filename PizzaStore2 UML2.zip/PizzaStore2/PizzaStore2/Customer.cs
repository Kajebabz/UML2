﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore2
{
    public class Customer
    {
        private static int nextId = 1;

        public Customer()
        {
            Id = nextId++;
        }

        public Customer(string name, string email, string phone, Address address)
        {
            Id = nextId++;
            Name = name;
            Email = email;
            Phone = phone;
            Address = address;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public Address Address { get; set; }

        public override string ToString()
        {
            return $"{nameof(Id)}={Id.ToString()}, {nameof(Name)}={Name}, {nameof(Email)}={Email}, {nameof(Phone)}={Phone}, {nameof(Address)}={Address}";
        }
    }
}
