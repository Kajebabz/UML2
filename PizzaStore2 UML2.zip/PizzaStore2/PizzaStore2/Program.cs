﻿
using PizzaStore;
using PizzaStore2;

class program
{
    static void Main(String[] args)
    {
        Store store = new Store();
        store.Start();
    }
}