﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore2
{
    public class Order
    {
        public static int nextId = 1;
        public Order()
        {
            Id = nextId++;
        }

        public Order(Pizza pizza, Customer customer, Address deliveryAddress)
        {
            Id = nextId++;
            Pizza = pizza;
            Customer = customer;
            DeliveryAddress = deliveryAddress;
        }

        public int Id { get; set; }
        public Pizza Pizza { get; set; }
        public Customer Customer { get; set; }
        public Address DeliveryAddress { get; set; }


        private double CalculateTotalPrize(double price)
        {
            return (price) * 1.25 + 40;
        }
        public override string ToString()
        {
            return "Tak for din bestilling " + Customer.Name + "! Du har bestilt " + Pizza.Name + ", dit ordre nummer er: " + Id + " og din totale pris er: " + CalculateTotalPrize(Pizza.Price);
        }
    }
}
