﻿using PizzaStore2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore
{
    public class Store
    {
        public void Start()
        {
            Address address1 = new Address("Grønager", "2", "Gevninge", "4000");
            Address address2 = new Address("Gartnervang", "92 1st th", "Roskilde", "4000");
            Address address3 = new Address("Skomagergade", "65 st mf", "Holbæk", "4300");
            Address address4 = new Address("Maglegårdsvej", "159", "Roskilde", "4000");

            Customer customer1 = new Customer("Peter", "hopla123@yahoo.com", "60 53 23 53", address1);
            Customer customer2 = new Customer("Lars", "Momse54@jubii.dk", "50 30 63 62", address2);
            Customer customer3 = new Customer("Pernille Havtorn", "Pernille92@hotmail.com", "20 52 56 79", address3);


            Pizza pizza1 = new Pizza("Hawaii", "Tomat, ost, skinke, ananas", 59);
            Pizza pizza2 = new Pizza("Napoli", "Tomat, ost, kødsovs, løg", 65);
            Pizza pizza3 = new Pizza("Milano", "Tomat, ost, skinke, pepperoni, kebab, bacon", 78);
            Pizza pizza4 = new Pizza("Vezuvi", "Tomat, ost, skinke, kylling, salat, dressing", 72);

            Order order1 = new Order(pizza1, customer1, address4);
            Order order2 = new Order(pizza2, customer2, address2);
            Order order3 = new Order(pizza3, customer3, address3);

            CustomerFile.AddCustomer(customer1);
            CustomerFile.AddCustomer(customer2);
            CustomerFile.AddCustomer(customer3);
            // 3 customers added

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            CustomerFile.PrintCustomer();
            // viser alle customers added

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            CustomerFile.RemoveCustomerById(3);
            Console.WriteLine();
            CustomerFile.PrintCustomer();
            // viser alle customers igen, nu med en removed.

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            CustomerFile.UpdateCustomer(1, "phone", "99 99 99 99");
            CustomerFile.ReadCustomerById(1);
            Console.WriteLine();
            CustomerFile.UpdateCustomer(2, "Name", "Marcus Heimdahl");
            CustomerFile.ReadCustomerById(2);
            // viser update method på name og phone, og read method.

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            CustomerFile.SearchCustomerByName("Ingelise");
            Console.WriteLine();
            CustomerFile.SearchCustomerByName("Marcus Heimdahl");
            // viser search method hvor d er både findes og ikke findes en customer.

            Console.WriteLine();
            Console.WriteLine("======================================================================================");
            Console.WriteLine();

            PizzaMenu.AddPizza(pizza1);
            PizzaMenu.AddPizza(pizza2);
            PizzaMenu.AddPizza(pizza3);
            PizzaMenu.AddPizza(pizza4);
            Console.WriteLine();
            PizzaMenu.PrintPizza();
            // viser tilføjede pizzaer og printer menukort.

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            PizzaMenu.RemovePizza(4);
            Console.WriteLine();
            PizzaMenu.PrintPizza();
            // removed pizza

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            PizzaMenu.UpdatePizza(1, "toppings", "tomat, ost, skinke, ananas, rejer");
            Console.WriteLine();
            PizzaMenu.UpdatePizza(2, "name", "Roma");
            Console.WriteLine();
            PizzaMenu.UpdatePizza(3, "price", "85");
            Console.WriteLine();
            // viser update method

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            PizzaMenu.SearchPizzaById(1);
            Console.WriteLine();
            PizzaMenu.SearchPizzaByToppings("skinke");
            Console.WriteLine();
            PizzaMenu.SearchPizzaByToppings("Banan");
            // viser search methods både på ID og på toppings.

            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------------------------------");
            Console.WriteLine();

            Console.WriteLine(order1);
            Console.WriteLine(order2);
            Console.WriteLine(order3);


        }
    }
}
