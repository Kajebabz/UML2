﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore2
{
    public class CustomerFile
    {
        private static List<Customer> Customers = new List<Customer>();

        public static void AddCustomer(Customer customer)
        {
            Console.WriteLine("Added new customer");
            Customers.Add(customer);
        }

        public static void AddCustomer(string name, string email, string phone, Address address)
        {
            Console.WriteLine("Added new customer");
            Customers.Add(new Customer(name, email, phone, address));   
        }

        public static Customer RemoveCustomer(Customer customer)
        {
            Customers.Remove(customer);
            Console.WriteLine($"Removed Customer with id: {customer.Id}, {customer.Name}");
            return customer;    
        }

        public static Customer RemoveCustomerById(int id)   
        {
            foreach (Customer customer in Customers)
            {
                if (customer.Id == id)
                {
                    CustomerFile.RemoveCustomer(customer);
                    return customer;
                }
            }
            Console.WriteLine("Nothing Removed");
            return null;
        }

        public static Customer ReadCustomerById(int id)
        {
            foreach (Customer customer in Customers)
            {
                if (customer.Id == id)
                {
                    Console.WriteLine(customer);
                    Console.WriteLine("Showing Customer");
                    return customer;
                }
            }
            Console.WriteLine("No Customer with that ID");
            return null;
        }
        public static void PrintCustomer()
        {
            foreach (var Customer in Customers)
            {
                Console.WriteLine(Customer);
            }
            Console.WriteLine("All customers listed!");
        }

        public static void UpdateCustomer(int id, string field, string newValue)
        {
            foreach (Customer c in Customers)
            {
                if (c.Id == id)
                {
                    // switch = field er input/variable, hvis input matcher en case, så bliver case kørt.
                    // I dette tilfælde opdatere enten name, email eller phone.
                    // eksempel: Vi tager og vil opdatere ID 1's navn. Så vi skriver:
                    // eksempel: (1, "name", "nytnavn") <-- i metodens parameter. 

                    switch (field.ToLower())
                    {
                        case "name": c.Name = newValue;
                            Console.WriteLine($"Name for customer with id: {id} has been updated");
                            break;
                        case "email": c.Email = newValue;
                            Console.WriteLine($"Email for customer with id: {id} has been updated");
                            break;
                        case "phone": c.Phone = newValue;
                            Console.WriteLine($"Phone for customer with id: {id} has been updated");
                            break;
                    }
                }
            }
        }

        public static Customer SearchCustomerByName(string name)
        {
            foreach (Customer c in Customers)
            {
                if (c.Name.ToLower() == name.ToLower())
                {
                    Console.WriteLine("Customer found");
                    Console.WriteLine(c);
                    return c;   
                }
            }
            Console.WriteLine($"Could not find any customers with that name: {name}");
            return null;
        }

    }
}
